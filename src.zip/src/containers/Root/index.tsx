import { message } from 'antd';
import React, { Component } from 'react';

interface RootProps {}

const Root = React.memo((props: RootProps) => {
  const [isSettingAvailable, setIsSettingAvailable] = React.useState(false);
  React.useEffect(() => {
    setTimeout(() => {
      if (document.querySelector('.JoyaVc')) {
        message.success('Extension loaded up successfully');
      }
    }, 2000);
  }, []);

  if (isSettingAvailable) return <div></div>;
  else return <div></div>;
});

export default Root;
