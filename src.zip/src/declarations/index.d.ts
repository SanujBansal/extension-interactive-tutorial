// declaration.d.ts
declare module '*.css';
declare module '*.scss';
declare module '*.module.css';
declare module '*.module.scss';
declare module '*.png';
declare module '*.svg';
declare module '*.jsx';
declare module '*.js';
